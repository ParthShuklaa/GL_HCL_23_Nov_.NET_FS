﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;// for implemtihg CRUd Operation using SQL Server 

namespace Employee_Management_Systyem
{
    public partial class register : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!this.IsPostBack)
            {
                this.GridView1.DataBind();
            }
        }
        protected void Button1_Click(object sender, EventArgs e)
        {
                string con = "Data Source=Parth-pc;Initial Catalog=HCL_DB;Integrated Security=True";
                SqlConnection db = new SqlConnection(con);
                db.Open();
                string  insert = "Insert into EMPLOYEE(Name,Email,DOB,Country,Age,Dept) values('" + First_Name_TextBox1.Text + " ', '" + TextBox2.Text + "','" + TextBox3.Text + "', '" + TextBox4.Text + "', '" + TextBox5.Text + "','" + TextBox6.Text +"')";
                
            SqlCommand cmd = new SqlCommand(insert, db);
             int n = cmd.ExecuteNonQuery();
            if (n!=0)
            {
                Response.Write("<Script> alert('Data Inserted Sucessfully.!!!')</script>");
            }
            else
            {
                Response.Write("<Script> alert('Check your DB ...!!!')</script>");
            }
            db.Close(); 
        }
    }
}