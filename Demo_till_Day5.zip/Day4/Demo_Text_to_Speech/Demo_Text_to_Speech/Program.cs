﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Speech.Synthesis;
using System.Speech.Recognition;
using System.Net.Http.Headers;

namespace Demo_Text_to_Speech
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Step 1: Creating Object of Speech Synthesizer class 
            //Step 2: Taking input from the user 
            //Step 3: Calling speak() 

            SpeechSynthesizer spk  = new SpeechSynthesizer();
            SpeechRecognitionEngine RE = new SpeechRecognitionEngine();
            spk.SetOutputToDefaultAudioDevice();
            string txt = Console.ReadLine();
            spk.Speak(txt);

        }
    }
}
