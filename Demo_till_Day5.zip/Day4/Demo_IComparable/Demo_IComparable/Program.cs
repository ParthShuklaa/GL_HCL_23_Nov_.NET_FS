﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_IComparable
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Car[] cars = new Car[]
            {
                new Car() {Name = "Tesla" },
                new Car() {Name = "BMW"},
                new Car() {Name = "Audi"}
};
            Console.WriteLine("Before Sorting aray...!!!");
            Array.ForEach(cars, car => Console.WriteLine(car.Name));//using lamda Expression
            Array.Sort(cars);
            Console.WriteLine("After Sortiung Array ...!!");
            Array.ForEach(cars, car => Console.WriteLine(car.Name));//using lamda Expression
            
            Console.WriteLine(cars[0].CompareTo(cars[1]));
            Console.WriteLine(cars[1].CompareTo(cars[1])); //Same Object of class 
            Console.WriteLine(cars[1].CompareTo(cars[0]));
        }
    }

   public class Car : IComparable
    {
        
        public string Name { get; set; }
        public int ModelNo { get; set; }

        public int CompareTo(object obj)
        {
            if (!(obj is Car))
            {
                throw new ArgumentException("Compared object is not from the collection ");
            }
            Car car = obj as Car;
            return Name.CompareTo(car.Name);
        }
    }
}
