﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Employee
{
    public class HCLEmployee
    {
        [Required (ErrorMessage ="Employee {0} is required")]
        [StringLength(100,MinimumLength =3)]
        public string Name { get; set; }
        [Range(16,100,ErrorMessage="Age Should be between 16-100")]
        public int Age { get; set; }

        [DataType(DataType.PhoneNumber)]
        [Phone]
        public string PhoneNo { get; set; }

        [DataType(DataType.EmailAddress)]
        [EmailAddress]
        public string Email { get; set; }

    }
}
