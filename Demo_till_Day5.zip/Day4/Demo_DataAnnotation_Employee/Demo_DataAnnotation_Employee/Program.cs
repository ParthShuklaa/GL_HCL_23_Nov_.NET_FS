﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using Employee;

namespace Demo_DataAnnotation_Employee
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.ForegroundColor= ConsoleColor.White;
            Console.WriteLine("Demo Employee validation using Attributes-Data Annotation");
            Console.WriteLine("*********************************************************");
            //Step 1: Creating an object of class lib class
             HCLEmployee objEmployee = new HCLEmployee();
             //objEmployee.Name = "PKNARAYAN";
             objEmployee.Age = 17;
             objEmployee.PhoneNo = "12absjhf";
             objEmployee.Email = "Admin";

            ValidationContext context = new ValidationContext(objEmployee, null, null);
           // ValidationContext newContext = new ValidationContext(objEmployee);
            List<ValidationResult> results  = new List<ValidationResult>();//Creating a List opf validation result

            bool valid = Validator.TryValidateObject(objEmployee, context, results, true);

            if (!valid)
            {
                foreach (ValidationResult item in results)
                {
                    Console.ForegroundColor = ConsoleColor.Blue;
                    Console.WriteLine("Member name :{0}", item.MemberNames.First());
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine(":: {0}{1}", item.ErrorMessage, Environment.NewLine);
                }
            }
            Console.ForegroundColor = ConsoleColor.White;
            

        }

    }
}
