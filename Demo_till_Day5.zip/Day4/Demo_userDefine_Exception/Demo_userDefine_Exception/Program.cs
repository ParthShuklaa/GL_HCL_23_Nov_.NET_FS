﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_userDefine_Exception
{
    internal class Program
    {
        static void validateAge(int age)
        {
            if (age < 18) {
                throw new InvalidAgeException("Sorry, Age must be greater than 18");
            }
        }
        static void Main(string[] args)
        {
            Fitness Security= new Fitness();
            try
            {
                validateAge(19);
                Security.ShowFitnesstestResult();
            }
            catch (InvalidAgeException e)
            {
                Console.WriteLine(e.Message);
                
            }
            catch (TestFitnessTestFailedException e) { Console.WriteLine( "Another User define Exception: {0}",e.Message); }
        }
    }

    class InvalidAgeException : Exception
    {
        public InvalidAgeException( string message) : base(message)
        {

        }
    }

}
