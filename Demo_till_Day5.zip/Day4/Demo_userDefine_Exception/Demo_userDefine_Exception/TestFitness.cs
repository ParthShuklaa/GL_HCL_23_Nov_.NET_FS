﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Demo_userDefine_Exception
{
    internal class TestFitnessTestFailedException : Exception
    {
        public TestFitnessTestFailedException(string message): base(message)
        {

        }
    }
    class Fitness
    {
        //int points;
        //public Fitness(int value)
        //{
        //    points = value;
        //}
        public void ShowFitnesstestResult()
        {
            Console.WriteLine("Enter your fitness ratings..!!");
            int points = Convert.ToInt32(Console.ReadLine());
            if (points < 120)
            {
                throw (new TestFitnessTestFailedException("Player failed the fitness test..!!"));
            }
            else
            {
                Console.WriteLine("Player passed the fitness test..!!!");
            }
        }
    }
}
