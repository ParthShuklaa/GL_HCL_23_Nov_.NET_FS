﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace DemoExceptionHandling
{
    internal class Program
    {
        static void Main(string[] args)
        {
            DivideByZeroException obj1 = new DivideByZeroException();
            //Step 1: Declare an Array
            int[] marks = { 100, 200, 0, 750 };
            //Step 2: Display values of an array 
            for (int i = 0; i < marks.Length; i++)
            {
                Console.WriteLine(marks[i]);
            }
            //Step 3: try to access invalid index of array 

            //An Exception is thrown upon executing above line

            try
            {
                Console.WriteLine("Enter the index of Marks Array...!!");
                int choice = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine(marks[choice]);//Index out of Range 

                for (int i = 0; i < marks.Length; i++)
                {
                    Console.WriteLine(marks[i] / marks[i+1]);
                }
            }
            catch (IndexOutOfRangeException e)
            {
                Console.WriteLine(" An Exception has occured :{0}\n", e.Message);
                //Console.WriteLine(e.Source);
                //Console.WriteLine(e.StackTrace);
                //throw;
            }

            catch (Exception error)
            {
                Console.WriteLine("An Exception has occured:{0}",error.Message);
            }
            //default code will run irespective of error/exception
            finally { Console.WriteLine(" Thanks for using the application..Hope Exception Handling is clear !!!"); }
        }
    }
}
