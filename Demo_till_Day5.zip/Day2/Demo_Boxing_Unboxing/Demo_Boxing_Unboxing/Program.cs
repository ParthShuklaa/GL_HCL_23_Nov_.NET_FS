﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Boxing_Unboxing
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Understanding Boxing and UnBoxing...!!!");
            int year = 2022;//value types

            object year_of_Admission = year;//Boxing
            year = 2021;//new value to value type

            Console.WriteLine("Value - type of year is :{0} ",year);
            Console.WriteLine("Object - Type of Value is :{0}", year_of_Admission);
        }
    }
}
