﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Has_a_RelationShip_Composition
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Demo for has a relationShip ie Each \"Emp-has-a Address\"");
            Address address = new Address("J / 221", "Delhi", "DELHI-NCR", "10019", "INDIA");
            Employee emp = new Employee(10001, "James", address);
            emp.Display();
        }
    }
    class Address
    {
        public string AddressLine, City, State, PostalCode, Country;
        public Address(string AddLine1, string city, string state, string code, string country)
        {
            AddressLine = AddLine1;
            City = city;
            State = state;
            PostalCode = code;
            Country = country;
        }
    }

    class Employee
    {
        public Address address;//composition ie has- a relationShip
        public int ID;
        public string Name;
        public Employee(int id, string name, Address add)
        {
            ID = id;
            Name = name;
            address = add;
        }
        public void Display()
        {
            Console.WriteLine($"Employee ID  :{ID}");
            Console.WriteLine($"Employe Name :{Name}");
            Console.WriteLine($"Adress Line  :{address.AddressLine}");
            Console.WriteLine($"City         :{address.City}");
            Console.WriteLine($"State        :{address.State}");

        }
    }
}
