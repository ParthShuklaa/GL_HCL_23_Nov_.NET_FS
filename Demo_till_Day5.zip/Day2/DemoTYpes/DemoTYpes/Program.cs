﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace DemoTYpes
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Understanding Boxing and UnBoxing...!!!");
            int year = 2022;//value types

            object year_of_Admission = year;//Boxing - As Object is Root of all types in C#
            year = 2021;//new value to value type

            int Enrollment_year = (int) year_of_Admission;//Unboxing
            Console.WriteLine("Value - type of year is :{0} ", year);
            Console.WriteLine("Object - Type of Value is :{0}", year_of_Admission);
            Console.WriteLine("Value - type of year is :{0} ", Enrollment_year);

            //Employee Fresher = new Employee();
            //Fresher.Employee_ID = 101001;
             
            Employee Intern = new Employee();//Default
            Intern.Display_Employee();
            Intern.Organisation_name = "Orange telecom pvt ltd";
            Console.WriteLine(  Intern.Organisation_name);


            Employee Senior_Management = new Employee(101047, "Raj", "Kumar", "Testing");
            Senior_Management.Display_Employee();
            Senior_Management.Hourly_Wages = 50000;
            Console.WriteLine("After Adding Hourly wages as a Property .................");
            Senior_Management.Display_Employee();

            Employee Director = new Employee(101089, "S", "Kumar", "Development");
            Director.Display_Employee();

            Employee[] Batch_of_2022 = new Employee[]
            {
                new Employee(101047, "Raj", "Kumar", "Testing"),
               new Employee (101089, "S", "Kumar", "Development"),
               new Employee (010165,"M","Vijay","Automation")

        };
            for (int i = 0; i < Batch_of_2022.Length; i++)
            {
                Batch_of_2022[i].Display_Employee();
            }

            SeniorEmployee Batchof1981 = new SeniorEmployee(2022,"Marketing Head");
            Batchof1981.Display_Employee();

            //Console.WriteLine(Fresher.Employee_ID);
        }
    }
}
