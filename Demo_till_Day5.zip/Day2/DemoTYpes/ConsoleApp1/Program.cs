﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DemoTYpes;


namespace ConsoleApp1
{
    internal class Program : Employee
    {
        static void Main(string[] args)
        {
            var myclass = new Employee();
        }
    }
}
