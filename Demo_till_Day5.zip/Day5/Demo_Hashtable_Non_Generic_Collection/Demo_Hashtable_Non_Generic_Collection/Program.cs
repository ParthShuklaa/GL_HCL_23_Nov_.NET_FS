﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Hashtable_Non_Generic_Collection
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Implemeing HasTable - Non generic Table");
            Hashtable Userdetails = new Hashtable();
            Userdetails.Add(101, "JamesBond");
            Userdetails.Add(102, "Ethan Hunt");
            Userdetails.Add(104, "Black Adams");
            Userdetails.Add(99, "Green");
            Userdetails.Add(true, "Black Adams");
            Userdetails.Add('O', "GuestUser");
//Userdetails.Add('O', "GuestUser"); Duplicate Keys are not allowed
            Console.WriteLine("Count of our Hastable is :{0}",Userdetails.Count);
            foreach (DictionaryEntry item in Userdetails)
            {
                Console.WriteLine($"Key is{item.Key} value is :{item.Value}");
            }

            var cities = new Hashtable()
            {
                {"INDIA","Mumbai, Delhi, Pune" },
                {"USA","New York,Washington,Chicago" }
            };
            foreach (DictionaryEntry item in cities)
            {
                Console.WriteLine("Key:{0},Value:{1}", item.Key, item.Value);
            }
        }
    }
}
