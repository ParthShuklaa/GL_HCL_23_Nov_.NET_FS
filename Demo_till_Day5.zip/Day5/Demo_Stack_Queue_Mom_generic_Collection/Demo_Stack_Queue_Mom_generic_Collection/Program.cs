﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Stack_Queue_Mom_generic_Collection
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Stack<int> stack = new Stack<int>();//generic version can only hold values that are defined
            //Strongly types stack collection 
            stack.Push(1);
            //stack.Push("Second");//Not possible

            Stack mystack = new Stack();//LIFO
            mystack.Push(1);
            mystack.Push("Second");
            mystack.Push(true);
            mystack.Push('y');
            Console.WriteLine("This is thd top most element of the stack: {0}",mystack.Peek());
            Console.WriteLine("No of elements of stack :{0}",mystack.Count);
            foreach (var item in mystack)
            {
                Console.WriteLine(item);
            }
            //Displaying capacity of the stack
            //removing element from stack
            mystack.Pop();
            foreach (var item in mystack)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine("No of elements of stack :{0}", mystack.Count);
            //Checking for a value in a stack
            Console.WriteLine( "Checking if stack contains '1': {0} ",mystack.Contains(1));
            //clearing a stack
            
            mystack.Clear();
            Console.WriteLine(mystack.Count);
            foreach (var item in mystack)
            {
                Console.WriteLine(item);
            }

        }
    }
}
