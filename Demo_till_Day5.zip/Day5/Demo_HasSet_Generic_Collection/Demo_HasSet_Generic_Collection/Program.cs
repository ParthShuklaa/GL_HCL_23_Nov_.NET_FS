﻿using System;
using System.Collections.Generic;//Namespace
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_HasSet_Generic_Collection
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("IMplemeting HasSet - Generic Collection ");
            HashSet<string> set = new HashSet<string>();
            set.Add("a");
            set.Add("India ");
            set.Add("UK");

            HashSet<int> set2 = new HashSet<int>();
            set2.Add(199);
            set2.Add(201);
            set2.Add(99);
            set2.Add(1);


            foreach (var item in set2)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine( "Average of my Hasset is {0}" ,set2.Average());
            set2.Remove(199);
            Console.WriteLine("After removing 199 from the hashset: ");

            foreach (var item in set2)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine("Average of my Hasset is {0}", set2.Average());
        }
    }
}
