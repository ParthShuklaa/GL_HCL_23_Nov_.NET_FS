﻿using System;
using System.Collections;//need this namespace for implementing array loast
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DEmo_ArrayList_Non_generic
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("IMplemeting Array List - None-Generic Colelction ");

            ArrayList Top5Movies = new ArrayList();

            Console.WriteLine("capacity of my Array List is : {0}",Top5Movies.Capacity);
            Console.WriteLine("Count of my Array List is : {0}", Top5Movies.Count);
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("Enter  to add your  Movie name");
                object movie1 = Console.ReadLine();
                Top5Movies.Add(movie1);
            }
            

            //Console.WriteLine("capacity of my Array List is : {0}", Top5Movies.Capacity);
            //Console.WriteLine("Count of my Array List is : {0}", Top5Movies.Count);
            //Top5Movies.Add(786);
            //Console.WriteLine("capacity of my Array List is : {0}", Top5Movies.Capacity);
            //Console.WriteLine("Count of my Array List is : {0}", Top5Movies.Count);
            //Top5Movies.Add(true);
            //Top5Movies.Add('O');
            //Console.WriteLine("capacity of my Array List is : {0}", Top5Movies.Capacity);
            //Console.WriteLine("Count of my Array List is : {0}", Top5Movies.Count);

            //Top5Movies.Add(3.1444F);
            //Console.WriteLine("capacity of my Array List is : {0}", Top5Movies.Capacity);
            //Console.WriteLine("Count of my Array List is : {0}", Top5Movies.Count);
            //Console.WriteLine("Contents of my Array list is :\n");
            foreach (var item in Top5Movies)
            {
                Console.WriteLine(item);
            }

            Top5Movies.Reverse();
            foreach (var item in Top5Movies)
            {
                Console.WriteLine(item);
            }
            //other widely used Non-genweric collection are
            //Hashtable
            //Queue
            //Stack
            //Deleting elelemts in Array list
            Top5Movies.Remove('O');
            
            Console.WriteLine("After removing 'O' from Array list ");
            foreach (var item in Top5Movies)
            {
                Console.WriteLine(item);
            }

            Top5Movies.Insert(1, "TITANIC");
            foreach (var item in Top5Movies)
            {
                Console.WriteLine(item);
            }


          

        }
    }
}
