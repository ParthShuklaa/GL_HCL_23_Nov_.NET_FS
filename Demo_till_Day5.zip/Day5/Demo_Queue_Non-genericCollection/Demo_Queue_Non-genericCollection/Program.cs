﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Queue_Non_genericCollection
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Implementing Non-Generic Collection");

            Queue callerIds= new Queue();
            callerIds.Enqueue(1);
            callerIds.Enqueue("USA");
            callerIds.Enqueue(true); 
            callerIds.Enqueue(false);
            Console.WriteLine("count of elements in Queue: {0}",callerIds.Count);

            foreach (var item in callerIds)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine( "Checking if our Queue consist of  \"USA\" : {0} ",callerIds.Contains("USA"));

            callerIds.Dequeue();
            callerIds.Dequeue();
            foreach (var item in callerIds)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine("Checking if our Queue consist of  \"USA\" : {0} ", callerIds.Contains("USA")); ;

        }
    }
}
