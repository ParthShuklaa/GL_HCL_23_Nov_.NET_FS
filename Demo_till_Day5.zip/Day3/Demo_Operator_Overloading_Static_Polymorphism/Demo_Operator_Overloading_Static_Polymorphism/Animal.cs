﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Operator_Overloading_Static_Polymorphism
{
     abstract class Animal //i am Not allowed to create object
    {
        public string AnimalType;
        public abstract void No_Of_Legs();//Only declaration
        public  virtual void Speak()
        {
            Console.WriteLine("Animals can speak and can share what they are feeling..!!");
        }
        public void Speak(string msg)
        {
            Console.WriteLine(msg);
        }
        public void Speak( string msg, int no)
        {
            
        }
    }
    class Dog : Animal
    {
        public override void No_Of_Legs()
        {
            Console.WriteLine("Dog has 4 legs");
        } //abstract Method defination 

        public override void Speak()
        { Console.WriteLine("Dogs bark"); }

    }
    class Cat: Animal
    {
        public override void No_Of_Legs()
        {
            Console.WriteLine("Cat has 4 Legs");
        }//abstract Method defination 
    }
    class Student
    {
        public void Greetings()//Function Overloading 
        { Console.WriteLine("Good Morning .!!!!"); }
        public void Gretings( string msg) { Console.WriteLine(msg);}
        public void Greetings(string msg, int no)
        {
            for (int i = 0; i < no; i++)
            {
                Console.WriteLine(msg);
            }
        }
    }
}
