﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Demo_Operator_Overloading_Static_Polymorphism
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Complex c1 = new Complex();
            c1.Display();

            Complex c2 = new Complex(5,7);
            Complex c3 = new Complex(3,5);
            Complex c5 = Complex.Add(c2, c3);//As Add() is declared as static so can be called by class directly
            Complex c4 = c2 + c3;//calling Overloaded "+" Operator for addition of two complex no
            Complex myNo = Complex.Add(c2, c3, c4);//Function Overloading
            c4.Display();
            myNo.Display();

            //Animal mammal = new Animal();//not allowed 
        }
    }

    public class Complex
    {
        int real;
        int img;
        public Complex(int real = 0, int img = 0)
        {
            this.real = real;// this keyword is used to point out current instance ie object at runtime
            this.img = img;
        }
        public static Complex Add(Complex c1, Complex c2)//Adding two Complex no using method
        {
            Complex Temp = new Complex();//Creating a object of complex class 
            Temp.real = c1.real + c2.real; //Adding real part of complex no
            Temp.img = c1.img + c2.img; // Adding Img part of complex no
            return Temp; //returning temp

        }
        public static Complex Add( Complex a, Complex b, Complex c)//Function Overloading
        {
            Complex Temp = new Complex();
            Temp.real = a.real + b.real + c.real;
            Temp.img = a.img + b.img + c.img;
            return Temp;
        }
        public static Complex  operator +(Complex c1, Complex c2)//Adding twp complex no using + Operator
        {
            Complex Temp = new Complex();//Creating a object of complex class 
            Temp.real = c1.real + c2.real; //Adding real part of complex no
            Temp.img = c1.img + c2.img; // Adding Img part of complex no
            return Temp; //returning temp

        }
        public void Display()
        {
            Console.WriteLine($"Your complex No is : {real} +i{img}");
        }
    }
}
