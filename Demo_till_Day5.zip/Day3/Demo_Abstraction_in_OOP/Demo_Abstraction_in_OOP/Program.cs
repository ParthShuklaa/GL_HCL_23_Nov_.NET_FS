﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Abstraction_in_OOP
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Rectagle r = new Rectagle(3, 5);
            Console.WriteLine($"Area of the Rectagle :{r.GetArea()}\n Perimeter is:{r.GetPerimeter()}");
            Square s = new Square(5);
            Console.WriteLine($"Area of Square is :{s.GetArea()}\n Perimeter is :{s.GetPerimeter()}");
        }
    }
    
}
