﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Abstraction_in_OOP
{
    internal interface Shape
    {
        int GetArea();
        int GetPerimeter();
    }

    class Rectagle : Shape
    {
        int length;
        int bredth;
        public Rectagle( int l , int b)
        {
            length= l;
            bredth= b;
        }

        public int GetArea()
        {
            return length * bredth;
        }

        public int GetPerimeter()
        {
            return 2 * (length + bredth);
        }
    }
    class Square : Shape
    {
        int side;

        public Square(int s)
        {
            side = s;
        }

        public int GetArea()
        {
            return side * side;
        }

        public int GetPerimeter()
        {
           return 4 * side;
        }
    }
}
