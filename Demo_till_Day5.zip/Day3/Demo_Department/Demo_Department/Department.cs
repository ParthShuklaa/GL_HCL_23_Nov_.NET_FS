﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Department
{
    internal class Department
    {
        public string Name { get; set; }

        public Department(string name)
        {
                Name= name;
        }
        public Department()
        {
            Console.WriteLine("Department is getting creaṭed...Enter name");
            Name = Console.ReadLine();
        }

        public void DisplayDepartment()
        {
            Console.WriteLine($"Name of the Dept is :{Name}");
        }
    }
}
