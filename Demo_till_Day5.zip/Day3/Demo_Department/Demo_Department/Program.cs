﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Department
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Department ENT = new Department("ENT");
            Department Pediatrics = new Department();
            ENT.DisplayDepartment();
            Pediatrics.DisplayDepartment();
        }
    }
}
