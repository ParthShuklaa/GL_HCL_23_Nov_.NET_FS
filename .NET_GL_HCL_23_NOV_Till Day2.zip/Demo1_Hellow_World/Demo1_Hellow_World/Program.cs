﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo1_Hellow_World
{
    internal class Program
    {
        static void Main(string[] args)// This is the entry Point of our application 
        {
            //Console.WriteLine("Declaring three variables and displaying their sum");
            //int x=5, y=10, z=20;
            //Console.WriteLine(x+y+z);

            //for (int i = 0; i < 5; i++)
            //{
            //    Console.WriteLine(" I am Inside a For Loop...!!");
            //}

            ////Getting started with string 
            //string message = "A Quick brown Fox Jumps over the lazy DOG";//Declaration
            //Console.WriteLine(message);//Displaying

            ////Taking input from the user
            //Console.WriteLine(" Enter Yor Name ..?");//Displaying a Message
            //string name = Console.ReadLine();//Taking input from the user
            //Console.WriteLine(name);//Displaying the name variable


            ////What if user wants read a No
            //Console.WriteLine("Enter Your Age..?");
            //int age = Convert.ToInt32(Console.ReadLine());//Explicit Casting
            //Console.WriteLine(age);


            //Implicit casting - is done automatically
            int Age = 10;
            double myDouble = Age;
            Console.WriteLine(Age);
            Console.WriteLine(myDouble);

            //Explicit TYpe Casting 
            double tax = 18.55;
            int mytax = (int) tax;//here we have to cast value as
                                  //int before saving in  int type of variable
            Console.WriteLine(tax);
            Console.WriteLine(mytax);

            Console.WriteLine("Hello World .. This is my First Application..!!");
            Console.Read();
        }
    }
}
