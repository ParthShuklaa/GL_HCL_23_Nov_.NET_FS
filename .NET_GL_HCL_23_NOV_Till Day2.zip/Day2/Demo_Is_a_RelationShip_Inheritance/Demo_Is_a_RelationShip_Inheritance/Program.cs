﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Is_a_RelationShip_Inheritance
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Cubiod mycubiod = new Cubiod(3, 5, 9);
            Console.WriteLine($"Volume is : {mycubiod.Volume()}");
            Console.WriteLine($"Area is :  {mycubiod.Area()}");
            Console.WriteLine($"Perimeter is : {mycubiod.Perimeter()}");
        }
    }
    class Rectangle
    {
        //Data members
        public int length;
        public int bredth;
        //member function
        public int Area()
        {
            return length * bredth;
        }
        public int Perimeter()
        {
            return  2*(length + bredth);
        }
    }

    class Cubiod : Rectangle
    {
        public int height;
        public Cubiod( int l, int b, int h)
        {
            length= l;
            height= h;
            bredth= b;
        }
        public int Volume()
        {
            return length * bredth * height;
        }
    }
}
