﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Metadata.W3cXsd2001;
using System.Text;
using System.Threading.Tasks;

namespace DemoTYpes
{
     public class Employee
    {
        string OrganisationName; //private field
        public string Organisation_name//property
        {
            get { return OrganisationName;}
            set { OrganisationName = value;}
        }
        public int Employee_ID;
        public string Employee_FirstName;
        public string Employee_LastName;
        public string Department;
        public int Hourly_Wages { get; set; }
        public Employee()
        {
            Employee_ID= 1;
            Department = "No Decided Yet!!";
           
        }
        public Employee(int id, string Fname, string LName, string Dept, int wages)
        {

        }
        public Employee(int id, string Fname, string LName,  string Dept ) { 
            Employee_ID= id;
            Employee_FirstName= Fname;
            Employee_LastName= LName;
            Department= Dept;
        }//constructor
        public void Display_Employee()
        {
            Console.WriteLine( Employee_ID.ToString()+","+Employee_FirstName+","+Employee_LastName+","+Department+","+Hourly_Wages);
        }
        public void Read_EMP_Data()
        {

        }
    }
     class SeniorEmployee : Employee
    {
        public int year_of_Retirement { get; set; }
        public string LastPosition { get; set; }
        public SeniorEmployee( int Year, string position )
        {
            year_of_Retirement = Year;
            LastPosition = position;
        }
    }
}
