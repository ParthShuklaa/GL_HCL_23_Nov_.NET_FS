﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Array
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //What shoud i do, if i want to store names of 500 emp
            string[] name = { "Admin", "Guest User", "Temp User" };
            Console.WriteLine(name[0]);
            Console.WriteLine(name[1]);
            Console.WriteLine(name[2]);


            //string[] Destinations = new string[29] {" " };

            string[] Password;
            Password = new string[] { "QWERTY", "ASDFGH", "Login@2345" };

            Console.WriteLine("traversing array using For Loop...!!!!");
            //using for loop for displaying all the values of array
            for (int i = 0; i < name.Length; i++)
            {
                Console.WriteLine(name[i]);
            }
            name[0] = "Super user";
            Console.WriteLine("After Adding super user to the Array my Final Output is ...!!");
            for (int i = 0; i < name.Length; i++)
            {
                Console.WriteLine(name[i]);
            }

            //Forward Only Loop- read only Loop
            Console.WriteLine(" Displaying content of the Array using for each loop");
            foreach (var i in Password)
            {
                Console.WriteLine(i);
            }

            

        }
    }
}
