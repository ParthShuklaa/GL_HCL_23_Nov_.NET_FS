﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_string_Class
{
    internal class Program
    {
        static void Main(string[] args)
        {

            string txt = "value Entered by the user is incorrect!!!\n";//new Line
            string msg = "Use Password with a combination of '0-9',\"a-z\",\" A-Z\" ....!!!";

            Console.WriteLine(txt + msg);

            string firstName = "Virat";

            Console.WriteLine(firstName[1]);
            Console.WriteLine(firstName.Length);
            Console.WriteLine(firstName.IndexOf("V"));
            Console.WriteLine(firstName.IndexOf("t"));
            Console.WriteLine(firstName.Substring(2));


            //string lastname = "Kohli";
            ////string name = firstName + lastname;
            //string name = string.Concat(firstName, lastname);//here we are using Concat() defined 
            //                                                   // inside string class 


            //Console.WriteLine(name);
            ////String Interpoltion - 

            //string myname = $"My Fav cricketer is :{firstName} {lastname}";

            //Console.WriteLine(myname);



        }
    }

}
