﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DEmo_Maths_Class
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Math.PI);
            Console.WriteLine(Math.Max(9,21));
            Console.WriteLine(Math.Min(4,500));
            Console.WriteLine(Math.Sqrt(64));
            Console.WriteLine(Math.Abs(-5.67));
            Console.WriteLine(Math.Round(9.999));
        }
    }
}
