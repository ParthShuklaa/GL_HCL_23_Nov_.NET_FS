﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using DEmoGettingStrarted_Core_MVC.Models;

namespace DEmoGettingStrarted_Core_MVC.Data
{
    public class DEmoGettingStrarted_Core_MVCContext : DbContext
    {
        public DEmoGettingStrarted_Core_MVCContext (DbContextOptions<DEmoGettingStrarted_Core_MVCContext> options)
            : base(options)
        {
        }

        public DbSet<DEmoGettingStrarted_Core_MVC.Models.ProductTable> ProductTable { get; set; } = default!;
    }
}
