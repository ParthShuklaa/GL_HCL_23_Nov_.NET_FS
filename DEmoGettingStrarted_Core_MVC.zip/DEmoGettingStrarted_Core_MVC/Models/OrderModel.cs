﻿using System.ComponentModel.DataAnnotations;

namespace DEmoGettingStrarted_Core_MVC.Models
{
    public class ProductTable
    {
        [Key]
        public int Id { get; set; }
        [Display(Name = "Quantity")]
        public int Quantity { get; set; }
        public int ProductID { get; set; }
        public string? ProductName { get; set; }//declaraing as Nullable
        public int ProductTotal { get; set; }
        public int Price { get; set; }
    }
    public class  OrderDetail
    {
        //Hold list of orders Model Object
        public List<ProductTable>? OrderDetails { get; set; }//declaraing as Nullable
    }
}
