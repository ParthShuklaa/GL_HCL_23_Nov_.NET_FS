﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Dictionary_Sorted_Dictionary_generic
{
    public class Product
    {
        public int productId { get; set; }
        public string productname { get; set; }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            var productDict = new Dictionary<int, Product>();//Product type dictionary

            try
            {

                productDict.Add(1, new Product() { productId = 111, productname = "MobilePhone" });
                productDict.Add(2, new Product() { productId = 112, productname = "Laptop" });
                productDict.Add(3, new Product() { productId = 113, productname = "Tablet" });
               // productDict.Add(3, new Product() { productId = 114, productname = "Monitor" });

                //Display element of dictionary
                foreach (KeyValuePair<int, Product> item in productDict)
                {
                    Console.WriteLine($"Key:{item.Key}, value= {item.Value.productId},{item.Value.productname}" );
                }

                //Retriving an element with a Given key
                Console.WriteLine("Retriving an element with a Given key = 2");

                if (productDict.TryGetValue(2, out Product product1))//Assign value of object with key=2
                {
                    Console.WriteLine($"key ={0} exist, value = {product1.productId},{product1.productname}");
                } 

            }
            catch (ArgumentException e)//here we can use Expcetion as it is the base class of every exception type classes
            {
                Console.WriteLine(e.Message);

            }

            //Updating value in Dictionary
            productDict[3] = new Product() { productId = 114, productname = "LaptopCharger" };
            foreach (KeyValuePair<int, Product> item in productDict)
            {
                Console.WriteLine($"Key:{item.Key}, value= {item.Value.productId},{item.Value.productname}");
            }

            //Deleting a value in Dictionary
            productDict.Remove(1);
            foreach (KeyValuePair<int, Product> item in productDict)
            {
                Console.WriteLine($"Key:{item.Key}, value= {item.Value.productId},{item.Value.productname}");
            }
            Console.WriteLine("Simple Dictionary class implementation ");
            Dictionary<int,string> MykeyValuePairs= new Dictionary<int,string>();
            MykeyValuePairs.Add(1, "Admin");
            MykeyValuePairs.Add(2, "User");
            MykeyValuePairs.Add(3, "Guest");

            if (MykeyValuePairs.TryGetValue(3, out string myvalue))
            {
                Console.WriteLine($"key:{2} exist,Value={myvalue}");
            } 
            
        }
    }
}
