﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DEmo_LinkList_Generics
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Implemtatioh of Linkedlist - Generics");

            string[] empID = { "EMP001", "EMP002", "EMP003", "EMP004", "EMP005", "EMP006" };//string array
            LinkedList<string> Emplist = new LinkedList<string>(empID);//linkedlist initiliazed with array
            foreach (var item in Emplist)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine(Emplist.Count);
            Console.WriteLine($" First element of the list \"Head\"{Emplist.First.Value} and the next node is {Emplist.First.Next.Value}");
            Console.WriteLine($"Last node of the linkedlist is {Emplist.Last.Value} and second last is {Emplist.Last.Previous.Value}");

            Emplist.AddFirst("EMP000");
            Emplist.AddLast("EMP007");
            Emplist.AddAfter(Emplist.Find("EMP003"), "EMP003.5");//(Node, Value of new Node)
            Emplist.AddBefore(Emplist.Last, "EMP006.5");
            foreach (var item in Emplist)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine("EMP005 is there in the Linked list:{0} ", Emplist.Find("EMP005").Value);
            Console.WriteLine(Emplist.Contains("EMP006.5"));
            Emplist.Remove("EMP003.5");
            Emplist.Remove("EMP006.5");
            Console.WriteLine("After removing EMP004.5 and EMP006.5 our list is :");
            foreach (var item in Emplist)
            {
                Console.WriteLine(item);
            }
            //Adding LinkedList node after first node using new operator 
            Emplist.AddAfter(Emplist.First, new LinkedListNode<string>("EMP00.5") );
            foreach (var item in Emplist)
            {
                Console.WriteLine(item.GetHashCode());
            }


        }
    }
}
