﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Generics_List_SortedSet
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("IMpleting generics classes");
            List<int> list = new List<int>();//G
                                             //eneric
            ArrayList mylist = new ArrayList();//Non-generic
            list.Add(1);
            Console.WriteLine(   list.Capacity);
            Console.WriteLine(list.Count);
            list.Add(2);
            
            foreach (var item in list)
            {
                Console.WriteLine(item);
            }
            list.RemoveAt(1);
            foreach (var item in list)
            {
                Console.WriteLine(item);
            }

            // list.Add("@");
            List<string> list2 = new List<string>();


            ///Creating a set of strings
            var ourbranches = new   SortedSet<string>();
            ourbranches.Add("India");
            ourbranches.Add("Japan");
            ourbranches.Add("Canada");
            ourbranches.Add("Australia");
            ourbranches.Add("Australia");
            Console.WriteLine(ourbranches.Count());
            
            var HQ = new SortedSet<string> {"India", "Canada", "Australia", "Japan" , "Canada" };
            foreach (var item in HQ) { Console.WriteLine(item); }
            //var name = "kartik";
            //var age = 20;
            foreach (var office in ourbranches)//here var is implicit types variable
            {
                Console.WriteLine(office);
            }

            ourbranches.Remove("Australia");
            Console.WriteLine("List of cities after removing 'Australia'");
            //ourbranches.Clear();
            Console.WriteLine("removing canada using Removewhere()");
            ourbranches.RemoveWhere(x => x =="India");
            foreach (var item in ourbranches) { Console.WriteLine(item); }
            foreach (var office in ourbranches)//here var is implicit types variable
            {
                Console.WriteLine(office);
            }

            //How will you check availability of an element
            if (ourbranches.Contains("India") == true)
            {
                Console.WriteLine(" We have Our Head office in India also..!!");
            }
            else
            {
                Console.WriteLine("We dont have head office in India ");
            }

        }
    }
}
