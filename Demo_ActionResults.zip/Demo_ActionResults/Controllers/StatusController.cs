﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Demo_ActionResults.Controllers
{
    public class StatusController : Controller
    {
        // GET: Status
        public HttpStatusCodeResult Index()
        {
            //return new HttpStatusCodeResult(System.Net.HttpStatusCode.OK);
            // return new HttpStatusCodeResult(System.Net.HttpStatusCode.Unauthorized);
            //return new HttpStatusCodeResult(System.Net.HttpStatusCode.Unauthorized,"SORRY !!! ONLY ADMIN CAN ACCESS THIS VIEW...!!!");
            //return new HttpUnauthorizedResult("SORRY !!! ONLY ADMIN CAN ACCESS THIS VIEW...!!!");
            return HttpNotFound("Sorry! You dont have access...!!!");
        }
    

        // GET: Status/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: Status/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Status/Create
        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Status/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: Status/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Status/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: Status/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
