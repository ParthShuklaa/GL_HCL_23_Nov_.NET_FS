﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Demo_ActionResults.Controllers
{
    public class StudentController : Controller
    {
        // GET: Student
        public RedirectToRouteResult Index()
        {
            //return View();
            //return Redirect("https://www.hcltech.com/");
            //return RedirectToRoute(new {Controller ="Student", Action= "DetailsData" });
            return RedirectToAction("Name");
            //If controller is same and we directly want to
            //refer to Action methods we can call it directly
        }
        public PartialViewResult Name()
        {
            return PartialView("_SecondView");
        }
        public ContentResult Showtable()
        {
            //return Content("<h2> here we will have Student table ...!!!</h2>");
            return Content("<script> alert('Firing Alert from MVC action methods') </script>");
        }
        public EmptyResult Details()
        {
            return new EmptyResult();
            //return nothing, have to create an object as there is no helper methods
        }
        public ActionResult EmptyDetails()
        {
            //return new EmptyResult();
            return null;
        }
         public FileResult ShowData()
        {//Returning file content in the browser
            //return File("C:\\Users\\dell\\source\\repos\\.NET_GL_HCL_23_NOV\\Day40\\Demo_ActionResults\\Demo_ActionResults\\mytext.txt ", "text/plain");

            //byte[] fileBytes = System.IO.File.ReadAllBytes(Server.MapPath("~/Files/mytext.txt"));
            //return File(fileBytes, "text/plain");
            //returning complete file in the browser
            return File(Url.Content("~/Files/mytext.txt"), "text/plain", "Schedule.txt");
        }
        public JsonResult DetailsData()
        {
            return Json(new { Name = "kartik", ID = 1 }, JsonRequestBehavior.AllowGet);
        }
    }
}