﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Demo_ActionResults.Controllers
{
    public class HomeController : Controller
    {
        public ViewResult Index()
        {
            return View("SecondView");
            //We can call any other view using different action name with the help of ViewResult type

            //Incase of partial view there is no layout page content
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
        public PartialViewResult DisplayResult()
        {
            return PartialView("_SecondView");
        }
    }
}